<?php
	$server = 'localhost';
	$username = 'username';
	$password = 'password';
	$database = 'usuarios_prueba';
	
	try {
		$conn = new PDO("mysql:host=$server;dbname=$database;",$username, $password);
	} catch (PDOException $e) {
		die('Conexión Fallida: '.$e->getMessage());
	}
?>