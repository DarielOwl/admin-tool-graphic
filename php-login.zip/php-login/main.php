<?php
  session_start();

  require 'database.php';

  if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT * FROM usuarios WHERE cedula = :cedula');
    $records->bindParam(':cedula', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
      $user = $results;
    }
  }
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title title>BIENVENID@ <?=$user['nombre']?></title>
  </head>
  <body>
    <form action="logout.php">
    <h1>BIENVENIDO A LA PAGINA</h1>
    <p>Nombre del usuario: <?=$user['nombre']?> <?=$user['apellido']?></p>
    <p>Cedula: <?=$user['cedula']?></p>
    <p>Correo electronico: <?=$user['email']?></p>

    <!-- REFERENCIAS A LOS DEMÁS ARCHIVOS PHP -->
    <input type="submit" value="Desconectarse" id="Logout" />
    </form>
  </body>
</html>