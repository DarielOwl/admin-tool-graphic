<?php
  #Llama a la conexiín a la base de datos
	require 'database.php'
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenidos al LOGIN</title>
  </head>
  <body>
    <form action="login.php">
      <div>
        <h1>Inicio del Programa</h1>
        <!-- REFERENCIAS A LOS DEMÁS ARCHIVOS PHP -->
        <label for="Login">Botón de Inicio de Sesión</label>
        <br>
        <input type="submit" value="Ingresar al login" id="Login" />
      </div>

      <div> 
        <br>       
        <img src="images/index.gif">
      </div>
      
    </form>
  </body>
</html>