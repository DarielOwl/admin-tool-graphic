<?php
  session_start();

  require 'database.php';
  #Recibe la informacón enviada por el método POST 
  #Verifica si la contraseña o el email no estan vacios
  
  if (!empty($_POST['email']) && !empty($_POST['password'])) {
    $records = $conn->prepare('SELECT cedula, email, password FROM usuarios WHERE email = :email');
    $records->bindParam(':email', $_POST['email']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $message = '';
    
    if ((!empty($results)) && (strcmp($_POST['password'], $results['password']) == 0)) {
      $_SESSION['user_id'] = $results['cedula'];
      header("Location: /main.php");
    } else {
      $message = 'ERROR: Datos invalidos (Email o Contraseña)';
    }
  }
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/style.css">
    <title>Login</title>
  </head>
  <body>	
    <?php if(!empty($message)): ?>
      <p><?= $message ?></p>
    <?php endif;?>	

    <!-- ACCIÓN SOBRE ESTE PHP Y SE ENVÍA CON EL MÉTODO POST -->
    <form action="login.php" method="post">
      <?php 
        require 'partials/header.php'
      ?>
      <br>
      <table>
        <tr>
          <td>Ingrese su correo electronico</td>
          <td>Ingrese su contraseña</td>
        </tr>
        <tr>
          <td>
            <input type="text" name="email" placeholder="ingrese su EMAIL">
          </td>
          <td>
            <input type="password" name="password" placeholder="ingrese su CONTRASEÑA">
          </td>
        </tr>
      </table>
      <br>      
      <input type="submit" value="Iniciar">
    </form>
  </body>
</html>